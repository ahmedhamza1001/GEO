//  Notifications & messages scrollable
if($('.sidebar-fixed').length > 0){
    $('.sidebar-fixed').perfectScrollbar({
        theme:"dark"
    });
}